package org.medicare.dao;

import org.medicare.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
@Repository
public interface UserRepository extends JpaRepository<User,Integer>{
User findByUsernameAndPassword(String username,String password );
@Query("update User u set u.password=?1 where u.username=?2")
String chpass(String password ,String username);
}
