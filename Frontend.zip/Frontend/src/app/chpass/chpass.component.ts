import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-chpass',
  templateUrl: './chpass.component.html',
  styleUrls: ['./chpass.component.css']
})
export class ChpassComponent implements OnInit {

  constructor(private us:UserService,private router: Router,
    private route: ActivatedRoute
) { }

  ngOnInit(): void {
  }
  change()
{
  const x=(<HTMLInputElement>document.getElementById("uname")).value;
  const y=(<HTMLInputElement>document.getElementById("password")).value;
  this.us.changepass(x,y).subscribe();
  this.router.navigate(['/userpage'])
  alert("Password changed")
}


}
