import { Component, OnInit } from '@angular/core';
import { NgForm ,NgModel} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AuthenticationStatus } from '../models/authenticationstatus.model';
import { UserService } from '../services/user.service';
import { CartService } from '../services/cart.service';
import { users } from 'src/app/models/users.model';
import Swal from 'sweetalert2';
import { Registrationservice } from 'src/app/services/registration.service';
@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  authStatus: AuthenticationStatus | undefined;
  users:users |undefined;
  constructor(
    private userservice:UserService,
    private router: Router,
    private route: ActivatedRoute,
    private registrationservice:Registrationservice,
    
  ) { }
 
  ngOnInit(): void {
  }
  onSubmit(form: NgForm) {
    console.log(form.value.username, form.value.password);

    this.userservice
    .authenticate(form.value.username, form.value.password)
    .subscribe((res) => {
      this.authStatus = res;
      if (this.authStatus.authenticated) {
        
        alert('Successfully logged in!"');
        this.router.navigate(['/userpage'], {relativeTo: this.route});
      }
      else {
        
        alert("Invalid Credentials!")
        this.router.navigate(['/user'], { relativeTo: this.route});
        form.reset();
}
});
}
onSubmits(form: NgForm){
  this.registrationservice.register(form.value.first_name,form.value.last_name,form.value.mobile_no,form.value.age,form.value.username,form.value.password,form.value.gender).subscribe((reg)  => {
    this.users = reg;
  alert('Registration Successfull !! Please Log-In To Proceed');
    this.router.navigate(['/user'], { relativeTo: this.route});

  })
}
}
